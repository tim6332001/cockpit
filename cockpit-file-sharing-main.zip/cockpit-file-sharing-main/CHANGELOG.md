## Cockpit File Sharing 2.4.5-1

* add support for using samba varibles in path names